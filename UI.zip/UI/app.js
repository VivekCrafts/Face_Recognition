Dropzone.autoDiscover = false;

function init() {
    let dz = new Dropzone("#dropzone", {
        url: "/", // Dummy URL
        maxFiles: 1,
        addRemoveLinks: true,
        dictDefaultMessage: "Drop an image or click to upload",
        autoProcessQueue: false
    });

    dz.on("addedfile", function () {
        // Limit to one file at a time
        if (dz.files[1] != null) {
            dz.removeFile(dz.files[0]);
        }
    });

    dz.on("complete", function (file) {
        let imageData = file.dataURL;

        let url = "http://127.0.0.1:5000/classify_image";  // Adjust as per your server setup

        $.post(url, {
            image_data: imageData
        }, function (data, status) {
            if (!data || data.length === 0) {
                $("#resultHolder").hide();
                $("#error").show();
                return;
            }

            const players = ["lionel_messi", "maria_sharapova", "roger_federer", "serena_williams", "virat_kohli"];

            let match = null;
            let bestScore = -1;

            // Find the classification with the highest score
            for (let i = 0; i < data.length; ++i) {
                let maxScore = Math.max(...data[i].class_probability);
                if (maxScore > bestScore) {
                    match = data[i];
                    bestScore = maxScore;
                }
            }

            if (match) {
                $("#error").hide();
                $("#resultHolder").show();

                // Show matched player card (no score shown)
                $("#resultHolder").html($(`[data-player="${match.class}"]`).html());
            }
        });
    });

    // Trigger processing on button click
    $("#submitBtn").on('click', function () {
        dz.processQueue();
    });
}

$(document).ready(function () {
    $("#error").hide();
    $("#resultHolder").hide();
    init();
});
